<?php
include '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $file_name = $_FILES['file']['name'];
    $file_tmp = $_FILES['file']['tmp_name'];
    $file_size = $_FILES['file']['size'];
    $upload_dir = '../uploads/';
    $allowed_types = array('pdf', 'doc', 'docx');

    $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);

    if (in_array($file_ext, $allowed_types) && $file_size <= 2097152) {
        if (move_uploaded_file($file_tmp, $upload_dir.$file_name)) {
            $query = "INSERT INTO file (file_name) VALUES ('$file_name')";
            if ($conn->query($query) === TRUE) {
                echo "File uploaded and record created successfully";
            } else {
                echo "Error: " . $query . "<br>" . $conn->error;
            }
        } else {
            echo "Failed to upload file";
        }
    } else {
        echo "Invalid file type or file size too large";
    }
}
?>

<form action="upload.php" method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label for="file">File:</label>
        <input type="file" class="form-control" id="file" name="file" required>
    </div>
    <button type="submit" class="btn btn-primary">Upload</button>
</form>
