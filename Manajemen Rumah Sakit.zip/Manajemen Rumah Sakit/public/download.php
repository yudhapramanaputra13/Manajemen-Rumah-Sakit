<?php
include '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];

    $query = "SELECT file_name FROM file WHERE id=$id";
    $result = $conn->query($query);
    $row = $result->fetch_assoc();
    $file_name = $row['file_name'];
    $file_path = '../uploads/' . $file_name;

    if (file_exists($file_path)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($file_path).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file_path));
        readfile($file_path);
        exit;
    } else {
        echo "File not found";
    }
}
?>

<form action="download.php" method="post">
    <div class="form-group">
        <label for="id">File ID:</label>
        <input type="text" class="form-control" id="id" name="id" required>
    </div>
    <button type="submit" class="btn btn-primary">Download</button>
</form>
