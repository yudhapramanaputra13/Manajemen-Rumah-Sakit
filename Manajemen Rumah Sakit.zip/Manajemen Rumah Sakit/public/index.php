<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

include '../config/database.php';
include '../includes/header.php';

$role = $_SESSION['role'];

switch ($role) {
    case 'admin':
        include 'admin_dashboard.php';
        break;
    case 'dokter':
        include 'dokter_dashboard.php';
        break;
    case 'perawat':
        include 'perawat_dashboard.php';
        break;
    case 'resepsionis':
        include 'resepsionis_dashboard.php';
        break;
    default:
        echo "Invalid role";
        break;
}

include '../includes/footer.php';
?>
