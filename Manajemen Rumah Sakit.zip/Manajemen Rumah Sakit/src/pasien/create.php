<?php
session_start();
if ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'resepsionis') {
    header('Location: ../../public/login.php');
    exit();
}
include '../../config/database.php';
include '../../includes/header.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];
    $email = $_POST['email'];

    $query = "INSERT INTO pasien (nama, alamat, telepon, email) VALUES ('$nama', '$alamat', '$telepon', '$email')";
    
    if ($conn->query($query) === TRUE) {
        header('Location: read.php');
        exit();
    } else {
        echo "Error: " . $query . "<br>" . $conn->error;
    }
}

echo '<div class="container">';
echo '<div class="row">';
echo '<div class="col-md-12">';
echo '<h1>Create New Patient</h1>';
echo '<form method="POST" action="">';
echo '<div class="form-group">';
echo '<label for="nama">Nama:</label>';
echo '<input type="text" class="form-control" id="nama" name="nama" required>';
echo '</div>';
echo '<div class="form-group">';
echo '<label for="alamat">Alamat:</label>';
echo '<textarea class="form-control" id="alamat" name="alamat" required></textarea>';
echo '</div>';
echo '<div class="form-group">';
echo '<label for="telepon">Telepon:</label>';
echo '<input type="text" class="form-control" id="telepon" name="telepon" required>';
echo '</div>';
echo '<div class="form-group">';
echo '<label for="email">Email:</label>';
echo '<input type="email" class="form-control" id="email" name="email" required>';
echo '</div>';
echo '<button type="submit" class="btn btn-primary">Submit</button>';
echo '</form>';
echo '</div>';
echo '</div>';
echo '</div>';

include '../../includes/footer.php';
?>
