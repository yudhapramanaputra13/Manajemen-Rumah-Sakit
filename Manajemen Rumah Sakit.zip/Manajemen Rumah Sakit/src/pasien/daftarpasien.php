<?php
session_start();
if ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'resepsionis' && $_SESSION['role'] != 'perawat'&& $_SESSION['role'] != 'dokter') {
    header('Location: ../../public/login.php');
    exit();
}
include '../../config/database.php';

// Proses delete pasien
if(isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])){
    $id = $_GET['id'];
    $query_delete = "DELETE FROM pasien WHERE id = $id";
    if ($conn->query($query_delete) === TRUE) {
        echo '<div class="alert alert-success" role="alert">Data pasien berhasil dihapus.</div>';
    } else {
        echo '<div class="alert alert-danger" role="alert">Error: ' . $query_delete . '<br>' . $conn->error . '</div>';
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pasien</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { 
            background-image: url('../../assets/images/admin.jpg'); /* Ubah path ini sesuai dengan lokasi gambar kamu */
            background-size: cover; /* Mengatur ukuran gambar agar menutupi seluruh latar belakang */
            background-position: center; /* Mengatur posisi gambar di tengah */
            background-repeat: no-repeat; /* Mencegah pengulangan gambar */
            color: white; /* Mengatur warna teks agar terlihat jelas */
        }
        .container {
            background-color: rgba(255, 255, 255, 0.9); /* Warna latar belakang container dengan sedikit transparansi */
            padding: 20px;
            border-radius: 8px;
            color: black;
        }
        .table {
            background-color: rgba(255, 255, 255, 0.9); /* Warna latar belakang tabel dengan sedikit transparansi */
        }
        h1 {
            color: black; /* Mengatur warna teks agar terlihat jelas di atas latar belakang */
        }
        .btn-primary, .btn-warning, .btn-danger {
            margin-right: 5px;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown"
                   aria-haspopup="true" aria-expanded="false">
                    Pilih Menu >>>
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item" href="../pasien/read.php">Lihat Pasien</a>
                    <a class="dropdown-item" href="../dokter/read.php">Lihat Dokter</a>
                    <a class="dropdown-item" href="../janjitemu/read.php">Lihat Janji Temu</a>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Clinic Management</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../../public/logout.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1>Daftar Pasien</h1>

            <?php
            $query = "SELECT * FROM pasien";
            $result = $conn->query($query);

            if ($result->num_rows > 0) {
                echo '<table class="table table-striped">';
                echo '<thead><tr><th>ID</th><th>Nama</th><th>Alamat</th><th>Telepon</th><th>Email</th><th>Actions</th></tr></thead>';
                echo '<tbody>';
                while($row = $result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $row["id"] . '</td>';
                    echo '<td>' . $row["nama"] . '</td>';
                    echo '<td>' . $row["alamat"] . '</td>';
                    echo '<td>' . $row["telepon"] . '</td>';
                    echo '<td>' . $row["email"] . '</td>';
                    echo '<td>';
                    echo '<a href="update.php?id=' . $row["id"] . '" class="btn btn-warning btn-sm">Edit</a> ';
                    echo '<a href="?action=delete&id=' . $row["id"] . '" class="btn btn-danger btn-sm">Delete</a></td>';
                    echo '</tr>';
                }
                echo '</tbody>';
                echo '</table>';
            } else {
                echo "<p>No results</p>";
            }
            ?>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
