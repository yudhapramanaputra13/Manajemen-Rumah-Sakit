<?php
session_start();
if ($_SESSION['role'] != 'dokter' && $_SESSION['role'] != 'perawat') {
    header('Location: ../../public/login.php');
    exit();
}

include '../../config/database.php';
include '../../includes/header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_pasien = $_POST['id_pasien'];
    $tanggal_rekam = $_POST['tanggal_rekam'];
    $deskripsi = $_POST['deskripsi'];

    $query = "INSERT INTO rekammedis (id_pasien, tanggal_rekam, deskripsi) VALUES ('$id_pasien', '$tanggal_rekam', '$deskripsi')";
    if ($conn->query($query) === TRUE) {
        echo "<p>New record created successfully</p>";
    } else {
        echo "Error: " . $query . "<br>" . $conn->error;
    }
}
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1 class="mt-5">Create New Rekam Medis</h1>
            <form action="create.php" method="post">
                <div class="form-group">
                    <label for="id_pasien">ID Pasien:</label>
                    <input type="number" class="form-control" id="id_pasien" name="id_pasien" required>
                </div>
                <div class="form-group">
                    <label for="tanggal_rekam">Tanggal Rekam:</label>
                    <input type="datetime-local" class="form-control" id="tanggal_rekam" name="tanggal_rekam" required>
                </div>
                <div class="form-group">
                    <label for="deskripsi">Deskripsi:</label>
                    <textarea class="form-control" id="deskripsi" name="deskripsi" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
