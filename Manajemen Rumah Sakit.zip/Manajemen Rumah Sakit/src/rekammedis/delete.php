<?php
session_start();
if ($_SESSION['role'] != 'dokter' && $_SESSION['role'] != 'perawat') {
    header('Location: ../../public/login.php');
    exit();
}

include '../../config/database.php';

$id = $_GET['id'];

$query = "DELETE FROM rekammedis WHERE id='$id'";
if ($conn->query($query) === TRUE) {
    echo "<p>Record deleted successfully</p>";
} else {
    echo "Error: " . $query . "<br>" . $conn->error;
}
?>

<p><a href="read.php">Back to Rekam Medis</a></p>
