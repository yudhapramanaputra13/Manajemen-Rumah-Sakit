<?php
session_start();
if ($_SESSION['role'] != 'dokter' && $_SESSION['role'] != 'perawat') {
    header('Location: ../../public/login.php');
    exit();
}

include '../../config/database.php';
include '../../includes/header.php';

echo '<div class="container">';
echo '<div class="row">';
echo '<div class="col-md-12">';
echo '<h1 class="mt-5">Rekam Medis</h1>';
echo '<a href="create.php" class="btn btn-primary mb-3">buat rekam medis baru</a>';

$query = "SELECT * FROM rekammedis";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    echo '<table class="table table-striped">';
    echo '<thead><tr><th>ID</th><th>ID Pasien</th><th>Tanggal Rekam</th><th>Deskripsi</th><th>Actions</th></tr></thead>';
    echo '<tbody>';
    while($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row["id"] . '</td>';
        echo '<td>' . $row["id_pasien"] . '</td>';
        echo '<td>' . $row["tanggal_rekam"] . '</td>';
        echo '<td>' . $row["deskripsi"] . '</td>';
        echo '<td><a href="update.php?id=' . $row["id"] . '" class="btn btn-warning btn-sm">Edit</a> ';
        echo '<a href="delete.php?id=' . $row["id"] . '" class="btn btn-danger btn-sm">Delete</a></td>';
        echo '</tr>';
    }
    echo '</tbody>';
    echo '</table>';
} else {
    echo "<p>No results</p>";
}

echo '</div>';
echo '</div>';
echo '</div>';

include '../../includes/footer.php';
?>
