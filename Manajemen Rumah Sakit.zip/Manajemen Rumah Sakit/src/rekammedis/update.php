<?php
session_start();
if ($_SESSION['role'] != 'dokter' && $_SESSION['role'] != 'perawat') {
    header('Location: ../../public/login.php');
    exit();
}

include '../../config/database.php';
include '../../includes/header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $id_pasien = $_POST['id_pasien'];
    $tanggal_rekam = $_POST['tanggal_rekam'];
    $deskripsi = $_POST['deskripsi'];

    $query = "UPDATE rekammedis SET id_pasien='$id_pasien', tanggal_rekam='$tanggal_rekam', deskripsi='$deskripsi' WHERE id='$id'";
    if ($conn->query($query) === TRUE) {
        echo "<p>Record updated successfully</p>";
    } else {
        echo "Error: " . $query . "<br>" . $conn->error;
    }
} else {
    $id = $_GET['id'];
    $query = "SELECT * FROM rekammedis WHERE id='$id'";
    $result = $conn->query($query);
    $row = $result->fetch_assoc();
}
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1 class="mt-5">Update Rekam Medis</h1>
            <form action="update.php" method="post">
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                <div class="form-group">
                    <label for="id_pasien">ID Pasien:</label>
                    <input type="number" class="form-control" id="id_pasien" name="id_pasien" value="<?php echo $row['id_pasien']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="tanggal_rekam">Tanggal Rekam:</label>
                    <input type="datetime-local" class="form-control" id="tanggal_rekam" name="tanggal_rekam" value="<?php echo $row['tanggal_rekam']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="deskripsi">Deskripsi:</label>
                    <textarea class="form-control" id="deskripsi" name="deskripsi" rows="5" required><?php echo $row['deskripsi']; ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
