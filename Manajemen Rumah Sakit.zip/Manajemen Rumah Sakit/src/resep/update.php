<?php
session_start();
// Memperbolehkan akses untuk dokter dan resepsionis saja
if ($_SESSION['role'] != 'dokter' && $_SESSION['role'] != 'resepsionis') {
    header('Location: ../../public/login.php');
    exit();
}
include '../../config/database.php';
include '../../includes/header.php';

$id = $_GET['id'];
$query = "SELECT * FROM resep WHERE id='$id'";
$result = $conn->query($query);
$row = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_janji = $_POST['id_janji'];
    $obat = $_POST['obat'];
    $dosis = $_POST['dosis'];

    $query = "UPDATE resep SET id_janji='$id_janji', obat='$obat', dosis='$dosis' WHERE id='$id'";
    if ($conn->query($query) === TRUE) {
        echo "<p>Record updated successfully</p>";
    } else {
        echo "Error: " . $query . "<br>" . $conn->error;
    }
}
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1 class="mt-5">Update Resep</h1>
            <form action="update.php?id=<?php echo $id; ?>" method="post">
                <div class="form-group">
                    <label for="id_janji">ID Janji:</label>
                    <input type="number" class="form-control" id="id_janji" name="id_janji" value="<?php echo $row['id_janji']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="obat">Obat:</label>
                    <textarea class="form-control" id="obat" name="obat" required><?php echo $row['obat']; ?></textarea>
                </div>
                <div class="form-group">
                    <label for="dosis">Dosis:</label>
                    <textarea class="form-control" id="dosis" name="dosis" required><?php echo $row['dosis']; ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
