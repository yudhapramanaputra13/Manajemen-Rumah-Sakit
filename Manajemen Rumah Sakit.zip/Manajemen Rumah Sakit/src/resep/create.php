<?php
session_start();
// Memperbolehkan akses untuk dokter dan resepsionis saja
if ($_SESSION['role'] != 'dokter' && $_SESSION['role'] != 'resepsionis') {
    header('Location: ../../public/login.php');
    exit();
}
include '../../config/database.php';
include '../../includes/header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_janji = $_POST['id_janji'];
    $obat = $_POST['obat'];
    $dosis = $_POST['dosis'];

    // Periksa apakah id_janji ada di tabel janjitemu
    $check_query = "SELECT * FROM janjitemu WHERE id='$id_janji'";
    $check_result = $conn->query($check_query);
    if ($check_result->num_rows == 0) {
        echo "<div class='alert alert-danger' role='alert'>ID Janji tidak ditemukan. Silakan periksa kembali.</div>";
    } else {
        $query = "INSERT INTO resep (id_janji, obat, dosis) VALUES ('$id_janji', '$obat', '$dosis')";
        if ($conn->query($query) === TRUE) {
            echo "<div class='alert alert-success' role='alert'>Record created successfully</div>";
        } else {
            echo "Error: " . $query . "<br>" . $conn->error;
        }
    }
}
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1 class="mt-5">Create Resep</h1>
            <form action="create.php" method="post">
                <div class="form-group">
                    <label for="id_janji">ID Janji:</label>
                    <input type="number" class="form-control" id="id_janji" name="id_janji" required>
                </div>
                <div class="form-group">
                    <label for="obat">Obat:</label>
                    <textarea class="form-control" id="obat" name="obat" required></textarea>
                </div>
                <div class="form-group">
                    <label for="dosis">Dosis:</label>
                    <textarea class="form-control" id="dosis" name="dosis" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Create</button>
            </form>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
