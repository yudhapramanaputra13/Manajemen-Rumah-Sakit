<?php
session_start();
// Memperbolehkan akses untuk dokter dan resepsionis saja
if ($_SESSION['role'] != 'dokter' && $_SESSION['role'] != 'resepsionis') {
    header('Location: ../../public/login.php');
    exit();
}

include '../../config/database.php';

$id = $_GET['id'];
$query = "DELETE FROM resep WHERE id='$id'";

if ($conn->query($query) === TRUE) {
    echo "<p>Record deleted successfully</p>";
} else {
    echo "Error: " . $query . "<br>" . $conn->error;
}

header('Location: read.php');
exit();
?>
