<?php
include '../../config/database.php';
session_start();
if ($_SESSION['role'] != 'admin') {
    header('Location: ../../public/login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head> 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Admin - User Management</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { 
            padding: 20px; 
            background-image: url('../../assets/images/admin.jpg'); /* Ubah path ini sesuai dengan lokasi gambar kamu */
            background-size: cover; /* Mengatur ukuran gambar agar menutupi seluruh latar belakang */
            background-position: center; /* Mengatur posisi gambar di tengah */
            background-repeat: no-repeat; /* Mencegah pengulangan gambar */
            color: white; /* Mengatur warna teks agar terlihat jelas */
        }
        .table-responsive {
            margin-top: 20px;
        }
        .table {
            background-color: rgba(255, 255, 255, 0.9); /* Warna latar belakang tabel dengan sedikit transparansi */
            color: black; /* Warna teks dalam tabel */
        }
        .table th, .table td {
            color: black; /* Warna teks dalam tabel */
        }
        h1, h2 {
            color: white; /* Mengatur warna teks agar terlihat jelas di atas latar belakang */
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Pilih Menu >>>
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    
                    <a class="dropdown-item" href="../pasien/daftarpasien.php">Lihat Pasien</a>
                    <a class="dropdown-item" href="../dokter/daftardokter.php">Lihat Dokter</a>
                    <a class="dropdown-item" href="../janjitemu/daftarjanjitemu.php">Lihat Janji Temu</a>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Clinic Management</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../../public/logout.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>
<div class="container">
    <h1>Welcome Admin</h1>
    <h2>Daftar Pengguna</h2>
    <?php
    $query = "SELECT * FROM pengguna";
    $result = $conn->query($query);
    if ($result->num_rows > 0) {
        echo '<form action="delete_multiple.php" method="post" class="table-responsive">';
        echo '<table class="table table-striped table-hover">';
        echo '<thead><tr><th><input type="checkbox" id="select_all"/></th><th>ID</th><th>Username</th><th>Role</th><th>Actions</th></tr></thead>';
        echo '<tbody>';
        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td><input type="checkbox" name="ids[]" value="' . $row["id"] . '"/></td>';
            echo '<td>' . $row["id"] . '</td>';
            echo '<td>' . $row["username"] . '</td>';
            echo '<td>' . $row["role"] . '</td>';
            echo '<td><a href="update.php?id=' . $row["id"] . '" class="btn btn-warning btn-sm">Edit</a> ';
            echo '<a href="delete.php?id=' . $row["id"] . '" class="btn btn-danger btn-sm">Delete</a></td>';
            echo '</tr>';
        }
        echo '</tbody>';
        echo '</table>';
        echo '<button type="submit" class="btn btn-danger">Delete Selected</button>';
        echo '</form>';
    } else {
        echo "<p>No results found</p>";
    }
    ?>
    <script>
    document.getElementById('select_all').onclick = function() {
        var checkboxes = document.querySelectorAll('input[type="checkbox"]');
        for (var checkbox of checkboxes) {
            checkbox.checked = this.checked;
        }
    }
    </script>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
