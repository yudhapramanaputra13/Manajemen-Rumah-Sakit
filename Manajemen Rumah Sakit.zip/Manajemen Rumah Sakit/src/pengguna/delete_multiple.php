<?php
include '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['ids'])) {
    $ids = $_POST['ids'];
    $id_list = implode(',', array_map('intval', $ids));

    $query = "DELETE FROM pengguna WHERE id IN ($id_list)";
    if ($conn->query($query) === TRUE) {
        echo "Selected users have been deleted successfully.";
    } else {
        echo "Error: " . $conn->error;
    }
}
header('Location: read.php');
exit();
?>
