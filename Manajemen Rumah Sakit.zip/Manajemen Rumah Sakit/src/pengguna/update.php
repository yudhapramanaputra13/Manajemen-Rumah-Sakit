<?php
include '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $username = $_POST['username'];
    $role = $_POST['role'];

    $query = "UPDATE pengguna SET username='$username', role='$role' WHERE id=$id";
    if ($conn->query($query) === TRUE) {
        $success = "User updated successfully";
    } else {
        $error = "Error: " . $query . "<br>" . $conn->error;
    }
} else {
    $id = $_GET['id'];
    $query = "SELECT * FROM pengguna WHERE id=$id";
    $result = $conn->query($query);
    $row = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User - Clinic Management System</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card mt-5">
                <div class="card-body">
                    <h3 class="card-title text-center">Edit User</h3>
                    <?php if (isset($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    <form action="update.php" method="post">
                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                        <div class="form-group">
                            <label for="username">Username:</label>
                            <input type="text" class="form-control" id="username" name="username" value="<?php echo $row['username']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="role">Role:</label>
                            <select class="form-control" id="role" name="role" required>
                                <option value="admin" <?php if ($row['role'] == 'admin') echo 'selected'; ?>>Admin</option>
                                <option value="dokter" <?php if ($row['role'] == 'dokter') echo 'selected'; ?>>Dokter</option>
                                <option value="perawat" <?php if ($row['role'] == 'perawat') echo 'selected'; ?>>Perawat</option>
                                <option value="resepsionis" <?php if ($row['role'] == 'resepsionis') echo 'selected'; ?>>Resepsionis</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Update</button>
                    </form>
                    <a href="read.php" class="btn btn-link mt-3">Back to Users List</a>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
