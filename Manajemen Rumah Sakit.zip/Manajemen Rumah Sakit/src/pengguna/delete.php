<?php
include '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];

    $query = "DELETE FROM pengguna WHERE id=$id";
    if ($conn->query($query) === TRUE) {
        $success = "User deleted successfully";
    } else {
        $error = "Error deleting record: " . $conn->error;
    }
} else {
    $id = $_GET['id'];
    $query = "SELECT * FROM pengguna WHERE id=$id";
    $result = $conn->query($query);
    $row = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete User - Clinic Management System</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card mt-5">
                <div class="card-body">
                    <h3 class="card-title text-center">Delete User</h3>
                    <?php if (isset($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    <form action="delete.php" method="post">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <p>Are you sure you want to delete this user?</p>
                        <button type="submit" class="btn btn-danger btn-block">Delete</button>
                    </form>
                    <a href="read.php" class="btn btn-link mt-3">Back to Users List</a>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
