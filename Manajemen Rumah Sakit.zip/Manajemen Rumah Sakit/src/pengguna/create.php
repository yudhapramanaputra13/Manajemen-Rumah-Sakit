<?php
include '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    $query = "INSERT INTO pengguna (username, password, role) VALUES ('$username', '$password', '$role')";
    if ($conn->query($query) === TRUE) {
        echo "New user created successfully";
    } else {
        echo "Error: " . $query . "<br>" . $conn->error;
    }
}
?>

<form action="create.php" method="post">
    <div class="form-group">
        <label for="username">Username:</label>
        <input type="text" class="form-control" id="username" name="username" required>
    </div>
    <div class="form-group">
        <label for="password">Password:</label>
        <input type="password" class="form-control" id="password" name="password" required>
    </div>
    <div class="form-group">
        <label for="role">Role:</label>
        <select class="form-control" id="role" name="role" required>
            <option value="admin">Admin</option>
            <option value="dokter">Dokter</option>
            <option value="perawat">Perawat</option>
            <option value="resepsionis">Resepsionis</option>
        </select>
    </div>
    <button type="submit" class="btn btn-primary">Create</button>
</form>
<a href="read.php">Back to Users List</a>
