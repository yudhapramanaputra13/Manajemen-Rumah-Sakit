<?php
session_start();
if ($_SESSION['role'] != 'resepsionis') {
    header('Location: ../../public/login.php');
    exit();
}

include '../../config/database.php';
include '../../includes/header.php';

$id = $_GET['id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_janji = $_POST['id_janji'];
    $jumlah = $_POST['jumlah'];
    $status = $_POST['status'];

    // Validasi nilai status
    if ($status != 'dibayar' && $status != 'belum dibayar') {
        echo "Error: Status tidak valid.";
        exit();
    }

    $query = "UPDATE faktur SET id_janji='$id_janji', jumlah='$jumlah', status='$status' WHERE id='$id'";
    if ($conn->query($query) === TRUE) {
        header('Location: read.php');
        exit();
    } else {
        echo "Error: " . $query . "<br>" . $conn->error;
    }
} else {
    $query = "SELECT * FROM faktur WHERE id='$id'";
    $result = $conn->query($query);
    $row = $result->fetch_assoc();
}

// Mengambil janji yang valid
$janji_query = "SELECT janjitemu.id, CONCAT(pasien.nama, ' dengan Dr. ', dokter.nama) AS detail_janji
                FROM janjitemu
                JOIN pasien ON janjitemu.id_pasien = pasien.id
                JOIN dokter ON janjitemu.id_dokter = dokter.id";
$janji_result = $conn->query($janji_query);
?>

<div class="container">
    <h2>Update Faktur</h2>
    <form method="post" action="">
        <div class="form-group">
            <label for="id_janji">ID Janji Temu:</label>
            <select class="form-control" id="id_janji" name="id_janji" required>
                <?php while ($janji = $janji_result->fetch_assoc()): ?>
                    <option value="<?= $janji['id']; ?>" <?php if ($janji['id'] == $row['id_janji']) echo 'selected'; ?>>
                        <?= $janji['detail_janji']; ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="jumlah">Jumlah:</label>
            <input type="number" step="0.01" class="form-control" id="jumlah" name="jumlah" value="<?php echo $row['jumlah']; ?>" required>
        </div>
        <div class="form-group">
            <label for="status">Status:</label>
            <select name="status" class="form-control" id="status">
                <option value="belum dibayar" <?php if ($row['status'] == 'belum dibayar') echo 'selected'; ?>>Belum Dibayar</option>
                <option value="dibayar" <?php if ($row['status'] == 'dibayar') echo 'selected'; ?>>Sudah Dibayar</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

<?php
include '../../includes/footer.php';
?>
