<?php
session_start();
if ($_SESSION['role'] != 'resepsionis') {
    header('Location: ../../public/login.php');
    exit();
}

include '../../config/database.php';
include '../../includes/header.php';

// Mengambil janji yang valid
$query = "SELECT janjitemu.id, CONCAT(pasien.nama, ' dengan Dr. ', dokter.nama) AS detail_janji
          FROM janjitemu
          JOIN pasien ON janjitemu.id_pasien = pasien.id
          JOIN dokter ON janjitemu.id_dokter = dokter.id
          LEFT JOIN faktur ON janjitemu.id = faktur.id_janji
          WHERE faktur.id IS NULL OR faktur.status = 'belum dibayar'";
$result = $conn->query($query);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_janji = $_POST['id_janji'];
    $jumlah = $_POST['jumlah'];
    $status = $_POST['status'];

    // Check if id_janji exists in resep table
    $checkQuery = "SELECT id FROM resep WHERE id='$id_janji'";
    $checkResult = $conn->query($checkQuery);

    if ($checkResult->num_rows > 0) {
        $insert_query = "INSERT INTO faktur (id_janji, jumlah, status) VALUES ('$id_janji', '$jumlah', '$status')";

        if ($conn->query($insert_query) === TRUE) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $insert_query . "<br>" . $conn->error;
        }
    } else {
        echo "Error: ID Janji tidak valid.";
    }

    $conn->close();
}
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1>Create New Faktur</h1>
            <form action="create.php" method="POST">
                <div class="form-group">
                    <label for="id_janji">ID Janji</label>
                    <select class="form-control" id="id_janji" name="id_janji" required>
                        <option value="">Select Janji Temu</option>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <option value="<?= $row['id']; ?>"><?= $row['detail_janji']; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="jumlah">Jumlah</label>
                    <input type="number" class="form-control" id="jumlah" name="jumlah" step="0.01" required>
                </div>
                <div class="form-group">
                    <label for="status">Status</label>
                    <select class="form-control" id="status" name="status" required>
                        <option value="belum dibayar">Belum Dibayar</option>
                        <option value="dibayar">Dibayar</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Create Faktur</button>
            </form>
        </div>
    </div>
</div>

<?php
include '../../includes/footer.php';
?>
