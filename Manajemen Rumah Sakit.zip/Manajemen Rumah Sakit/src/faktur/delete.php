<?php
session_start();
if ($_SESSION['role'] != 'resepsionis') {
    header('Location: ../../public/login.php');
    exit();
}

include '../../config/database.php';

$id = $_GET['id'];
$query = "DELETE FROM faktur WHERE id='$id'";
if ($conn->query($query) === TRUE) {
    header('Location: read.php');
} else {
    echo "Error: " . $query . "<br>" . $conn->error;
}
?>
