<?php
session_start();
if ($_SESSION['role'] != 'resepsionis') {
    header('Location: ../../public/login.php');
    exit();
}

include '../../config/database.php';

if (isset($_GET['id'])) {
    $file_id = $_GET['id'];

    // Dapatkan detail file dari database
    $query = "SELECT * FROM file WHERE id = '$file_id'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $file = $result->fetch_assoc();
        $file_path = $file['path_file'];

        if (file_exists($file_path)) {
            // Mengirimkan header untuk download file
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($file_path));
            readfile($file_path);
            exit;
        } else {
            echo "File tidak ditemukan.";
        }
    } else {
        echo "File tidak ditemukan di database.";
    }
} else {
    echo "ID file tidak diberikan.";
}
?>
