<?php
session_start();
if ($_SESSION['role'] != 'resepsionis') {
    header('Location: ../../public/login.php');
    exit();
}

include '../../config/database.php';
include '../../includes/header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_rekam = $_POST['id_rekam'];
    $nama_file = $_FILES['file']['name'];
    $path_file = '../../file/' . basename($nama_file);
    $tipe_file = $_FILES['file']['type'];
    $ukuran_file = $_FILES['file']['size'];

    // Batasi ukuran file maksimal 2MB
    if ($ukuran_file > 2 * 1024 * 1024) {
        echo "Ukuran file terlalu besar. Maksimal 2MB.";
    } else {
        // Periksa apakah direktori file ada, jika tidak buat direktori tersebut
        if (!is_dir('../../file')) {
            mkdir('../../file', 0777, true);
        }

        if (move_uploaded_file($_FILES['file']['tmp_name'], $path_file)) {
            $query = "INSERT INTO file (id_rekam, nama_file, path_file, tipe_file) VALUES ('$id_rekam', '$nama_file', '$path_file', '$tipe_file')";
            if ($conn->query($query) === TRUE) {
                echo "File uploaded successfully";
            } else {
                echo "Error: " . $query . "<br>" . $conn->error;
            }
        } else {
            echo "Failed to upload file.";
        }
    }
}
?>

<div class="container">
    <h1>Upload File</h1>
    <form action="create.php" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="id_rekam">ID Rekam:</label>
            <input type="text" class="form-control" id="id_rekam" name="id_rekam" required>
        </div>
        <div class="form-group">
            <label for="file">File:</label>
            <input type="file" class="form-control" id="file" name="file" required>
        </div>
        <button type="submit" class="btn btn-primary">Upload</button>
    </form>
</div>

<?php include '../../includes/footer.php'; ?>
