<?php
session_start();
if ($_SESSION['role'] != 'resepsionis') {
    header('Location: ../../public/login.php');
    exit();
}

include '../../config/database.php';
include '../../includes/header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $id_rekam = $_POST['id_rekam'];
    $nama_file = $_FILES['file']['name'];
    $path_file = 'uploads/' . basename($nama_file);
    $tipe_file = $_FILES['file']['type'];

    if (move_uploaded_file($_FILES['file']['tmp_name'], $path_file)) {
        $query = "UPDATE file SET id_rekam='$id_rekam', nama_file='$nama_file', path_file='$path_file', tipe_file='$tipe_file' WHERE id='$id'";
        if ($conn->query($query) === TRUE) {
            echo "File updated successfully";
        } else {
            echo "Error: " . $query . "<br>" . $conn->error;
        }
    } else {
        echo "Failed to upload file.";
    }
} else {
    $id = $_GET['id'];
    $query = "SELECT * FROM file WHERE id='$id'";
    $result = $conn->query($query);
    $row = $result->fetch_assoc();
?>

<div class="container">
    <h1>Edit File</h1>
    <form action="update.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        <div class="form-group">
            <label for="id_rekam">ID Rekam:</label>
            <input type="text" class="form-control" id="id_rekam" name="id_rekam" value="<?php echo $row['id_rekam']; ?>" required>
        </div>
        <div class="form-group">
            <label for="file">File:</label>
            <input type="file" class="form-control" id="file" name="file" required>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>

<?php
}
include '../../includes/footer.php';
?>
