<?php
session_start();
if ($_SESSION['role'] != 'resepsionis') {
    header('Location: ../../public/login.php');
    exit();
}

include '../../config/database.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar File</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { 
            padding: 20px; 
            background-image: url('../../assets/images/resepsionis.jpg'); /* Ubah path ini sesuai dengan lokasi gambar kamu */
            background-size: cover; /* Mengatur ukuran gambar agar menutupi seluruh latar belakang */
            background-position: center; /* Mengatur posisi gambar di tengah */
            background-repeat: no-repeat; /* Mencegah pengulangan gambar */
            color: white; /* Mengatur warna teks agar terlihat jelas */
        }
        .container {
            background-color: rgba(255, 255, 255, 0.9); /* Warna latar belakang container dengan sedikit transparansi */
            padding: 20px;
            border-radius: 10px;
        }
        .table {
            background-color: white; /* Warna latar belakang tabel */
            color: black; /* Warna teks dalam tabel */
        }
        h1 {
            color: black; /* Mengatur warna teks agar terlihat jelas di atas latar belakang */
        }
        .navbar {
            background-color: rgba(0, 0, 0, 0.8); /* Warna latar belakang navbar dengan sedikit transparansi */
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Clinic Management</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Pilih Menu >>>
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item" href="../janjitemu/create.php">Buat Janji Temu</a>
                    <a class="dropdown-item" href="../pasien/read.php">Lihat Pasien</a>
                    <a class="dropdown-item" href="../resep/read.php">Lihat Resep</a>
                    <a class="dropdown-item" href="../faktur/read.php">Lihat Faktur</a>
                    <a class="dropdown-item" href="../file/read.php">Lihat Files</a>
                </div>
            </li>
        </ul>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="../../public/logout.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1 class="mt-5">Daftar File</h1>
            <a href="create.php" class="btn btn-primary mb-3">Upload New File</a>

            <?php
            $query = "SELECT * FROM file";
            $result = $conn->query($query);

            if ($result->num_rows > 0) {
                echo '<div class="table-responsive">';
                echo '<table class="table table-striped">';
                echo '<thead><tr><th>ID</th><th>ID Rekam</th><th>Nama File</th><th>Path File</th><th>Tipe File</th><th>Actions</th></tr></thead>';
                echo '<tbody>';
                while($row = $result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $row["id"] . '</td>';
                    echo '<td>' . $row["id_rekam"] . '</td>';
                    echo '<td>' . $row["nama_file"] . '</td>';
                    echo '<td>' . $row["path_file"] . '</td>';
                    echo '<td>' . $row["tipe_file"] . '</td>';
                    echo '<td>';
                    echo '<a href="update.php?id=' . $row["id"] . '" class="btn btn-warning btn-sm">Edit</a> ';
                    echo '<a href="delete.php?id=' . $row["id"] . '" class="btn btn-danger btn-sm">Delete</a> ';
                    echo '<a href="' . $row["path_file"] . '" class="btn btn-success btn-sm" download>Download</a>';
                    echo '</td>';
                    echo '</tr>';
                }
                echo '</tbody>';
                echo '</table>';
                echo '</div>';
            } else {
                echo "<p>No results</p>";
            }
            ?>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
