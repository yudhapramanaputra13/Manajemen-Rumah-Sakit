<?php
session_start();
if ($_SESSION['role'] != 'resepsionis') {
    header('Location: ../../public/login.php');
    exit();
}

include '../../config/database.php';

$id = $_GET['id'];
$query = "DELETE FROM file WHERE id='$id'";

if ($conn->query($query) === TRUE) {
    echo "File deleted successfully";
} else {
    echo "Error: " . $query . "<br>" . $conn->error;
}

header('Location: read.php');
exit();
?>
