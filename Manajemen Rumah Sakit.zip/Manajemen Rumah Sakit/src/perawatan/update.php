<?php
session_start();
if ($_SESSION['role'] != 'perawat') {
    header('Location: ../../public/login.php');
    exit();
}

include '../../config/database.php';
include '../../includes/header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $deskripsi = $_POST['deskripsi'];
    $biaya = $_POST['biaya'];

    $query = "UPDATE perawatan SET nama='$nama', deskripsi='$deskripsi', biaya='$biaya' WHERE id=$id";
    if ($conn->query($query) === TRUE) {
        echo "<p>Record updated successfully</p>";
    } else {
        echo "Error: " . $query . "<br>" . $conn->error;
    }
} else {
    $id = $_GET['id'];
    $query = "SELECT * FROM perawatan WHERE id=$id";
    $result = $conn->query($query);
    $row = $result->fetch_assoc();
}
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1 class="mt-5">Update Record</h1>
            <form action="update.php" method="post">
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                <div class="form-group">
                    <label for="nama">Nama:</label>
                    <input type="text" class="form-control" id="nama" name="nama" value="<?php echo $row['nama']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="deskripsi">Deskripsi:</label>
                    <textarea class="form-control" id="deskripsi" name="deskripsi" required><?php echo $row['deskripsi']; ?></textarea>
                </div>
                <div class="form-group">
                    <label for="biaya">Biaya:</label>
                    <input type="number" step="0.01" class="form-control" id="biaya" name="biaya" value="<?php echo $row['biaya']; ?>" required>
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
