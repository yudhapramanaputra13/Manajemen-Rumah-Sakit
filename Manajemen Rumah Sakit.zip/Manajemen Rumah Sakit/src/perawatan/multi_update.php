<?php
session_start();
include '../../config/database.php';

if ($_SESSION['role'] != 'perawat') {
    header('Location: ../../public/login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['selected_ids'])) {
    foreach ($_POST['selected_ids'] as $id) {
        if (isset($_POST['biaya'][$id])) {
            $biaya = $_POST['biaya'][$id];
            $query = "UPDATE perawatan SET biaya = ? WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param('di', $biaya, $id);
            $stmt->execute();
        }
    }
    header('Location: read.php');
    exit();
} else {
    echo "No data to update.";
}
?>
