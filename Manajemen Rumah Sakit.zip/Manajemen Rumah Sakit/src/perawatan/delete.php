<?php
session_start();
if ($_SESSION['role'] != 'perawat') {
    header('Location: ../../public/login.php');
    exit();
}

include '../../config/database.php';

$id = $_GET['id'];

$query = "DELETE FROM perawatan WHERE id=$id";
if ($conn->query($query) === TRUE) {
    header('Location: read.php');
    exit();
} else {
    echo "Error: " . $conn->error;
}
?>
