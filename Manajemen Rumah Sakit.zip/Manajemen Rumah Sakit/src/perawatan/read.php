<?php
session_start();
if ($_SESSION['role'] != 'perawat') {
    header('Location: ../../public/login.php');
    exit();
}

include '../../config/database.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Perawatan</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body, html {
            height: 100%;
            margin: 0;
        }
        .bg-video {
            position: absolute;
            right: 0;
            bottom: 0;
            min-width: 100%;
            min-height: 100%;
            z-index: -1;
            opacity: 0.7; /* Adjust opacity if needed */
        }
        .container {
            position: relative;
            z-index: 1;
            background-color: rgba(255, 255, 255, 0.9); /* Warna latar belakang container dengan sedikit transparansi */
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
        }
        .table {
            background-color: white; /* Warna latar belakang tabel */
            color: black; /* Warna teks dalam tabel */
        }
        .btn-group, .btn {
            margin-bottom: 20px;
        }
        h1 {
            color: black; /* Mengatur warna teks agar terlihat jelas di atas latar belakang */
        }
    </style>
</head>
<body>
    <video autoplay muted loop class="bg-video">
        <source src="../../assets/images/perawat.mp4" type="video/mp4">
    </video>

    <?php include '../../includes/header.php'; ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="mt-5">Manage Perawatan</h1>
                <div class="btn-group mb-3" role="group" aria-label="Basic example">
                    <a href="../pasien/read.php" class="btn btn-info">lihat Pasien</a>
                    <a href="create.php" class="btn btn-primary">buat kebutuhan pasien</a>
                    <a href="../catatanperawatan/read.php" class="btn btn-secondary">riwayat catatan perawatan</a>
                    <a href="../rekammedis/daftarrekam.php" class="btn btn-info">lihat rekam medis</a>
                </div>
                <form action="multi_update.php" method="post">
                    <table class="table">
                        <thead><tr><th>Check</th><th>ID</th><th>Nama</th><th>Deskripsi</th><th>Biaya</th><th>Actions</th></tr></thead>
                        <tbody>
                            <?php
                            $query = "SELECT * FROM perawatan";
                            $result = $conn->query($query);
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td><input type='checkbox' name='selected_ids[]' value='{$row['id']}'></td>";
                                echo "<td>{$row['id']}</td>";
                                echo "<td>{$row['nama']}</td>";
                                echo "<td>{$row['deskripsi']}</td>";
                                echo "<td><input type='text' name='biaya[{$row['id']}]' value='{$row['biaya']}' class='form-control'></td>";
                                echo "<td><a href='update.php?id={$row['id']}' class='btn btn-warning btn-sm'>Edit</a> ";
                                echo "<a href='delete.php?id={$row['id']}' class='btn btn-danger btn-sm'>Delete</a></td>";
                                echo "</tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                    <button type="submit" class="btn btn-success">Update Selected</button>
                </form>
            </div>
        </div>
    </div>

    <?php include '../../includes/footer.php'; ?>
</body>
</html>
