<?php
session_start();
if ($_SESSION['role'] != 'perawat') {
    header('Location: ../../public/login.php');
    exit();
}

include '../../config/database.php';
include '../../includes/header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $deskripsi = $_POST['deskripsi'];
    $biaya = $_POST['biaya'];

    $query = "INSERT INTO perawatan (nama, deskripsi, biaya) VALUES ('$nama', '$deskripsi', '$biaya')";
    if ($conn->query($query) === TRUE) {
        echo "<p>New record created successfully</p>";
    } else {
        echo "Error: " . $query . "<br>" . $conn->error;
    }
}
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1 class="mt-5">Create New Record</h1>
            <form action="create.php" method="post">
                <div class="form-group">
                    <label for="nama">Nama:</label>
                    <input type="text" class="form-control" id="nama" name="nama" required>
                </div>
                <div class="form-group">
                    <label for="deskripsi">Deskripsi:</label>
                    <textarea class="form-control" id="deskripsi" name="deskripsi" required></textarea>
                </div>
                <div class="form-group">
                    <label for="biaya">Biaya:</label>
                    <input type="number" step="0.01" class="form-control" id="biaya" name="biaya" required>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
