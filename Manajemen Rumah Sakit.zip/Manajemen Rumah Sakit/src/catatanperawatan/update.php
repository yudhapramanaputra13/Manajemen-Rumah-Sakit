<?php
session_start();
if ($_SESSION['role'] != 'dokter' && $_SESSION['role'] != 'perawat') {
    header('Location: ../../public/login.php');
    exit();
}

include '../../config/database.php';
include '../../includes/header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $id_rekam = $_POST['id_rekam'];
    $id_perawatan = $_POST['id_perawatan'];

    $query = "UPDATE catatanperawatan SET id_rekam='$id_rekam', id_perawatan='$id_perawatan' WHERE id='$id'";
    if ($conn->query($query) === TRUE) {
        echo "<div class='alert alert-success' role='alert'>Record updated successfully</div>";
    } else {
        echo "Error: " . $query . "<br>" . $conn->error;
    }
} else {
    $id = $_GET['id'];
    $query = "SELECT * FROM catatanperawatan WHERE id='$id'";
    $result = $conn->query($query);
    $row = $result->fetch_assoc();
?>

<div class="container">
    <h2>Update Catatan Perawatan</h2>
    <form method="POST" action="update.php">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        <div class="form-group">
            <label for="id_rekam">ID Rekam Medis:</label>
            <input type="number" class="form-control" id="id_rekam" name="id_rekam" value="<?php echo $row['id_rekam']; ?>" required>
        </div>
        <div class="form-group">
            <label for="id_perawatan">ID Perawatan:</label>
            <input type="number" class="form-control" id="id_perawatan" name="id_perawatan" value="<?php echo $row['id_perawatan']; ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
        <a href="read.php" class="btn btn-secondary mt-3">Cancel</a>
    </form>
</div>

<?php
}
include '../../includes/footer.php';
?>
