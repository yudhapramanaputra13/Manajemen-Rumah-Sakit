<?php
session_start();
if ($_SESSION['role'] != 'perawat') {
    header('Location: ../../public/login.php');
    exit();
}

include '../../config/database.php';
include '../../includes/header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_rekam = $_POST['id_rekam'];
    $id_perawatan = $_POST['id_perawatan'];
    
    $query = "INSERT INTO catatanperawatan (id_rekam, id_perawatan) VALUES ('$id_rekam', '$id_perawatan')";
    
    if ($conn->query($query) === TRUE) {
        header('Location: read.php');
        exit(); // Penting: pastikan untuk keluar setelah melakukan redirect
    } else {
        echo "Error: " . $query . "<br>" . $conn->error;
    }
}
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h2 class="mt-5">Create New Catatan Perawatan</h2>
            <form action="create.php" method="post">
                <div class="form-group">
                    <label for="id_rekam">ID Rekam Medis</label>
                    <input type="number" name="id_rekam" id="id_rekam" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="id_perawatan">ID Perawatan</label>
                    <input type="number" name="id_perawatan" id="id_perawatan" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary mt-3">Submit</button>
                <a href="read.php" class="btn btn-secondary mt-3">Cancel</a>
            </form>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
