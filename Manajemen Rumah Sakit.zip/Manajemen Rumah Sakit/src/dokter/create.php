<?php
include '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $namaArray = $_POST['nama'];
    $spesialisasiArray = $_POST['spesialisasi'];
    $teleponArray = $_POST['telepon'];
    $emailArray = $_POST['email'];

    $errors = [];
    foreach ($namaArray as $index => $nama) {
        $spesialisasi = $spesialisasiArray[$index];
        $telepon = $teleponArray[$index];
        $email = $emailArray[$index];

        $query = "INSERT INTO dokter (nama, spesialisasi, telepon, email) VALUES ('$nama', '$spesialisasi', '$telepon', '$email')";
        if (!$conn->query($query)) {
            $errors[] = "Error: " . $query . "<br>" . $conn->error;
        }
    }

    if (empty($errors)) {
        echo "All doctors created successfully";
    } else {
        echo implode('<br>', $errors);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Doctor - Clinic Management System</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card mt-5">
                <div class="card-body">
                    <h3 class="card-title text-center">Create New Doctor</h3>
                    <?php if (isset($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    <form action="create.php" method="post">
                        <div id="doctor-forms">
                            <div class="doctor-form">
                                <div class="form-group">
                                    <label for="nama[]">Nama:</label>
                                    <input type="text" class="form-control" id="nama" name="nama[]" required>
                                </div>
                                <div class="form-group">
                                    <label for="spesialisasi[]">Spesialisasi:</label>
                                    <input type="text" class="form-control" id="spesialisasi" name="spesialisasi[]" required>
                                </div>
                                <div class="form-group">
                                    <label for="telepon[]">Telepon:</label>
                                    <input type="text" class="form-control" id="telepon" name="telepon[]" required>
                                </div>
                                <div class="form-group">
                                    <label for="email[]">Email:</label>
                                    <input type="email" class="form-control" id="email" name="email[]" required>
                                </div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-secondary" id="add-doctor">Add Another Doctor</button>
                        <button type="submit" class="btn btn-primary btn-block mt-3">Create</button>
                    </form>
                    <a href="read.php" class="btn btn-link mt-3">Back to Doctor List</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('add-doctor').addEventListener('click', function() {
    var newDoctorForm = document.querySelector('.doctor-form').cloneNode(true);
    document.getElementById('doctor-forms').appendChild(newDoctorForm);
});
</script>
</body>
</html>
