<?php
include '../../config/database.php';

session_start();
if ($_SESSION['role'] != 'admin') {
    header('Location: ../../public/login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head> 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Admin - Daftar Dokter</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
  body { 
            padding: 20px; 
            background-image: url('../../assets/images/dokter.jpg'); 
            background-size: cover; 
            background-position: center; /* Mengatur posisi gambar di tengah */
            background-repeat: no-repeat; /* Mencegah pengulangan gambar */
            color: white; /* Mengatur warna teks agar terlihat jelas */
        }
        .container {
            background-color: rgba(255, 255, 255, 0.9); /* Warna latar belakang container dengan sedikit transparansi */
            padding: 20px;
            border-radius: 10px;
        }
        .table {
            background-color: white; /* Warna latar belakang tabel */
            color: black; /* Warna teks dalam tabel */
        }
        .btn-group, .btn {
            margin-bottom: 20px;
        }
        h1, h2 {
            color: black; /* Mengatur warna teks agar terlihat jelas di atas latar belakang */
        }
        .navbar {
            background-color: rgba(0, 0, 0, 0.8); /* Warna latar belakang navbar dengan sedikit transparansi */
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Clinic Management</a>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
            <li>
            <a href="create.php" class="nav-link">Buat Dokter Baru</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../../public/logout.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>
<div class="container">
    <h1>Welcome Admin</h1>
    <h2>Daftar Dokter</h2>
    <?php
    $query = "SELECT * FROM dokter";
    $result = $conn->query($query);
    if ($result->num_rows > 0) {
        echo '<table class="table table-striped">';
        echo '<thead><tr><th>ID</th><th>Nama</th><th>Spesialisasi</th><th>Telepon</th><th>Email</th><th>Actions</th></tr></thead>';
        echo '<tbody>';
        while($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . $row["id"] . '</td>';
            echo '<td>' . $row["nama"] . '</td>';
            echo '<td>' . $row["spesialisasi"] . '</td>';
            echo '<td>' . $row["telepon"] . '</td>';
            echo '<td>' . $row["email"] . '</td>';
            echo '<td><a href="update.php?id=' . $row["id"] . '" class="btn btn-warning btn-sm">Edit</a> ';
            echo '<a href="delete.php?id=' . $row["id"] . '" class="btn btn-danger btn-sm">Delete</a></td>';
            echo '</tr>';
        }
        echo '</tbody>';
        echo '</table>';
    } else {
        echo "<p>No results</p>";
    }
    ?>
</div>

<?php include '../../includes/footer.php'; ?>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

 