<?php
include '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];

    $query = "DELETE FROM dokter WHERE id=$id";
    if ($conn->query($query) === TRUE) {
        echo "Doctor deleted successfully";
    } else {
        echo "Error deleting record: " . $conn->error;
    }
} else {
    $id = $_GET['id'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Doctor - Clinic Management System</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card mt-5">
                <div class="card-body">
                    <h3 class="card-title text-center">Delete Doctor</h3>
                    <?php if (isset($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    <form action="delete.php" method="post">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <p>Are you sure you want to delete this doctor?</p>
                        <button type="submit" class="btn btn-danger btn-block">Delete</button>
                    </form>
                    <a href="read.php" class="btn btn-link mt-3">Back to Doctor List</a>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
</form>

