<?php
include '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $spesialisasi = $_POST['spesialisasi']; // Mengubah 'spesialis' menjadi 'spesialisasi'
    $telepon = $_POST['telepon'];
    $email = $_POST['email'];

    // Query update dengan kolom yang benar 'spesialisasi'
    $query = "UPDATE dokter SET nama='$nama', spesialisasi='$spesialisasi', telepon='$telepon', email='$email' WHERE id=$id";
    if ($conn->query($query) === TRUE) {
        echo "Doctor updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }
} else {
    $id = $_GET['id'];
    $query = "SELECT * FROM dokter WHERE id=$id";
    $result = $conn->query($query);
    $row = $result->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Doctor - Clinic Management System</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card mt-5">
                <div class="card-body">
                    <h3 class="card-title text-center">Edit Doctor</h3>
                    <?php if (isset($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    <form action="update.php" method="post">
                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                        <div class="form-group">
                            <label for="nama">Nama:</label>
                            <input type="text" class="form-control" id="nama" name="nama" value="<?php echo $row['nama']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="spesialisasi">Spesialisasi:</label> <!-- Mengubah 'spesialis' menjadi 'spesialisasi' -->
                            <input type="text" class="form-control" id="spesialisasi" name="spesialisasi" value="<?php echo $row['spesialisasi']; ?>" required> <!-- Mengubah 'spesialis' menjadi 'spesialisasi' -->
                        </div>
                        <div class="form-group">
                            <label for="telepon">Telepon:</label>
                            <input type="text" class="form-control" id="telepon" name="telepon" value="<?php echo $row['telepon']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo $row['email']; ?>" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Update</button>
                    </form>
                    <a href="read.php" class="btn btn-link mt-3">Back to Doctor List</a>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
