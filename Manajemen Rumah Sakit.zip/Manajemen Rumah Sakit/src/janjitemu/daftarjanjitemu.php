<?php
include '../../config/database.php';
session_start();
if (!isset($_SESSION['role']) || ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'dokter')) {
    header('Location: ../../public/login.php');
    header('Location: ../../public/login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head> 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Admin - Daftar Janji Temu</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { 
            padding: 20px; 
            background-image: url('../../assets/images/admin.jpg'); 
            background-size: cover; 
            background-position: center; 
            background-repeat: no-repeat; 
            color: white; 
        }
        .container {
            background-color: rgba(255, 255, 255, 0.9); 
            padding: 20px;
            border-radius: 10px;
        }
        .table {
            background-color: white; 
            color: black; 
        }
        h1, h2 {
            color: white; 
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Clinic Management</a>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Pilih Menu >>>
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item" href="../pasien/read.php">Lihat Pasien</a>
                    <a class="dropdown-item" href="../dokter/daftardokter.php">Lihat Dokter</a>
                    <a class="dropdown-item" href="../janjitemu/read.php">Lihat Janji Temu</a>
                </div>
            </li>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../../public/logout.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>
<div class="container">
<h1 style="color: black;">Welcome Admin</h1>
<h2 style="color: black;">Daftar Janji Temu</h2>
    <?php
    $query = "SELECT * FROM janjitemu";
    $result = $conn->query($query);
    if ($result->num_rows > 0) {
        echo '<table class="table table-striped">';
        echo '<thead><tr><th>ID</th><th>ID Pasien</th><th>ID Dokter</th><th>Tanggal</th><th>Status</th><th>Actions</th></tr></thead>';
        echo '<tbody>';
        while($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . $row["id"] . '</td>';
            echo '<td>' . $row["id_pasien"] . '</td>';
            echo '<td>' . $row["id_dokter"] . '</td>';
            echo '<td>' . $row["tanggal_janji"] . '</td>';
            echo '<td>' . $row["status"] . '</td>';
            echo '<td>';
            echo '<a href="update.php?id=' . $row["id"] . '" class="btn btn-warning btn-sm">Edit</a> ';
            echo '<a href="delete.php?id=' . $row["id"] . '" class="btn btn-danger btn-sm">Delete</a> ';
            echo '</td>';
            echo '</tr>';
        }
        echo '</tbody>';
        echo '</table>';
    } else {
        echo "<p>No results found</p>";
    }
    ?>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
