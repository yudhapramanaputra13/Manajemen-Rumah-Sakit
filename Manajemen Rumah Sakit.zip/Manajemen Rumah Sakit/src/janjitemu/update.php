<?php
include '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $id_pasien = $_POST['id_pasien'];
    $id_dokter = $_POST['id_dokter'];
    $tanggal_janji = $_POST['tanggal_janji'];
    $status = $_POST['status'];

    $query = "UPDATE janjitemu SET id_pasien='$id_pasien', id_dokter='$id_dokter', tanggal_janji='$tanggal_janji', status='$status' WHERE id=$id";
    if ($conn->query($query) === TRUE) {
        $success = "Appointment updated successfully";
    } else {
        $error = "Error: " . $query . "<br>" . $conn->error;
    }
} else {
    $id = $_GET['id'];
    $query = "SELECT * FROM janjitemu WHERE id=$id";
    $result = $conn->query($query);
    $row = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Appointment - Clinic Management System</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card mt-5">
                <div class="card-body">
                    <h3 class="card-title text-center">Edit Appointment</h3>
                    <?php if (isset($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    <form action="update.php" method="post">
                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                        <div class="form-group">
                            <label for="id_pasien">ID Pasien:</label>
                            <input type="text" class="form-control" id="id_pasien" name="id_pasien" value="<?php echo $row['id_pasien']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="id_dokter">ID Dokter:</label>
                            <input type="text" class="form-control" id="id_dokter" name="id_dokter" value="<?php echo $row['id_dokter']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="tanggal_janji">Tanggal Janji:</label>
                            <input type="datetime-local" class="form-control" id="tanggal_janji" name="tanggal_janji" value="<?php echo $row['tanggal_janji']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="status">Status:</label>
                            <select class="form-control" id="status" name="status" required>
                                <option value="dijadwalkan" <?php if ($row['status'] == 'dijadwalkan') echo 'selected'; ?>>Dijadwalkan</option>
                                <option value="selesai" <?php if ($row['status'] == 'selesai') echo 'selected'; ?>>Selesai</option>
                                <option value="batal" <?php if ($row['status'] == 'batal') echo 'selected'; ?>>Batal</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Update</button>
                    </form>
                    <a href="read.php" class="btn btn-link mt-3">Back to Appointment List</a>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
