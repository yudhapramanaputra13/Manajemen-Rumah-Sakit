<?php
session_start();
if ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'resepsionis') {
    header('Location: ../../public/login.php');
    exit();
}

include '../../config/database.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Janji Temu</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { 
            padding: 20px; 
            background-image: url('../../assets/images/resepsionis.jpg'); 
            background-size: cover; 
            background-position: center; 
            background-repeat: no-repeat; 
            color: white; 
        }
        .container {
            background-color: rgba(255, 255, 255, 0.9); 
            padding: 20px;
            border-radius: 10px;
        }
        .table {
            background-color: white; 
            color: black; 
        }
        h1 {
            color: black; 
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Clinic Management</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Pilih Menu >>>
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item" href="create.php">Buat Janji Temu</a>
                    <a class="dropdown-item" href="../pasien/read.php">Lihat Pasien</a>
                    <a class="dropdown-item" href="../resep/daftarresep.php">Lihat Resep</a>
                    <a class="dropdown-item" href="../faktur/read.php">Lihat Faktur</a>
                    <a class="dropdown-item" href="../file/read.php">Lihat Files</a>
                </div>
            </li>
        </ul>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="../../public/logout.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1>Daftar Janji Temu</h1>

            <?php
            $query = "SELECT * FROM janjitemu";
            $result = $conn->query($query);

            if ($result->num_rows > 0) {
                echo '<table class="table table-striped">';
                echo '<thead><tr><th>ID</th><th>ID Pasien</th><th>ID Dokter</th><th>Tanggal</th><th>Status</th><th>Formulir</th><th>Actions</th></tr></thead>';
                echo '<tbody>';
                while($row = $result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $row["id"] . '</td>';
                    echo '<td>' . $row["id_pasien"] . '</td>';
                    echo '<td>' . $row["id_dokter"] . '</td>';
                    echo '<td>' . $row["tanggal_janji"] . '</td>';
                    echo '<td>' . $row["status"] . '</td>';
                    echo '<td>';
                    if ($row['formulir']) {
                        echo '<a href="../../uploads/forms/' . $row['formulir'] . '" target="_blank">View Formulir</a>';
                    } else {
                        echo '<form action="upload_formulir.php" method="post" enctype="multipart/form-data">';
                        echo '<input type="file" name="formulir" required>';
                        echo '<input type="hidden" name="id_janji" value="' . $row['id'] . '">';
                        echo '<button type="submit" class="btn btn-primary btn-sm">Upload</button>';
                        echo '</form>';
                    }
                    echo '</td>';
                    echo '<td>';
                    echo '<a href="update.php?id=' . $row["id"] . '" class="btn btn-warning btn-sm">Edit</a> ';
                    echo '<a href="delete.php?id=' . $row["id"] . '" class="btn btn-danger btn-sm">Delete</a> ';
                    echo '</td>';
                    echo '</tr>';
                }
                echo '</tbody>';
                echo '</table>';
            } else {
                echo "<p>No results</p>";
            }
            ?>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
