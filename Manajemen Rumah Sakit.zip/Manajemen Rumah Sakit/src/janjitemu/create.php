<?php
session_start();
if ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'resepsionis') {
    header('Location: ../../public/login.php');
    exit();
}

include '../../config/database.php';
include '../../includes/header.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_pasien = $_POST['id_pasien'];
    $id_dokter = $_POST['id_dokter'];
    $tanggal_janji = $_POST['tanggal_janji'];
    $status = $_POST['status'];

    $query = "INSERT INTO janjitemu (id_pasien, id_dokter, tanggal_janji, status) VALUES ('$id_pasien', '$id_dokter', '$tanggal_janji', '$status')";
    
    if ($conn->query($query) === TRUE) {
        header('Location: read.php');
        exit();
    } else {
        echo "Error: " . $query . "<br>" . $conn->error;
    }
}

echo '<div class="container">';
echo '<div class="row">';
echo '<div class="col-md-12">';
echo '<h1>Create New Appointment</h1>';
echo '<form method="POST" action="">';
echo '<div class="form-group">';
echo '<label for="id_pasien">ID Pasien:</label>';
echo '<input type="number" class="form-control" id="id_pasien" name="id_pasien" required>';
echo '</div>';
echo '<div class="form-group">';
echo '<label for="id_dokter">ID Dokter:</label>';
echo '<input type="number" class="form-control" id="id_dokter" name="id_dokter" required>';
echo '</div>';
echo '<div class="form-group">';
echo '<label for="tanggal_janji">Tanggal Janji:</label>';
echo '<input type="datetime-local" class="form-control" id="tanggal_janji" name="tanggal_janji" required>';
echo '</div>';
echo '<div class="form-group">';
echo '<label for="status">Status:</label>';
echo '<select class="form-control" id="status" name="status" required>';
echo '<option value="dijadwalkan">Dijadwalkan</option>';
echo '<option value="selesai">Selesai</option>';
echo '</select>';
echo '</div>';
echo '<button type="submit" class="btn btn-primary">Submit</button>';
echo '</form>';
echo '</div>';
echo '</div>';
echo '</div>';

include '../../includes/footer.php';
?>
