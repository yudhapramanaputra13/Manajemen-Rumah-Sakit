<?php
session_start();
include '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_janji = $_POST['id_janji'];
    $formulir = $_FILES['formulir']['name'];
    $path_formulir = '../../uploads/forms/' . basename($formulir);
    $tipe_formulir = $_FILES['formulir']['type'];

    // Validasi tipe file (misalnya hanya dokumen word atau pdf)
    $allowed_types = ['application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/pdf'];
    if (!in_array($tipe_formulir, $allowed_types)) {
        echo "Tipe file tidak diizinkan. Hanya dokumen Word dan PDF.";
        exit;
    }

    // Pastikan direktori tujuan ada
    if (!file_exists('../../uploads/forms/')) {
        mkdir('../../uploads/forms/', 0755, true);
    }

    // Pindahkan file yang diupload ke direktori yang diinginkan
    if (move_uploaded_file($_FILES['formulir']['tmp_name'], $path_formulir)) {
        // Update path file di database
        $query = "UPDATE janjitemu SET formulir='$formulir' WHERE id='$id_janji'";
        if (mysqli_query($conn, $query)) {
            header('Location: read.php');
            exit();
        } else {
            echo "Gagal mengupdate formulir di database.";
        }
    } else {
        echo "Gagal mengunggah file.";
    }
}
?>
