-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for clinic_management_schema
CREATE DATABASE IF NOT EXISTS `clinic_management_schema` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `clinic_management_schema`;

-- Dumping structure for table clinic_management_schema.catatanperawatan
CREATE TABLE IF NOT EXISTS `catatanperawatan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_rekam` int DEFAULT NULL,
  `id_perawatan` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_rekam` (`id_rekam`),
  KEY `id_perawatan` (`id_perawatan`),
  CONSTRAINT `catatanperawatan_ibfk_1` FOREIGN KEY (`id_rekam`) REFERENCES `rekammedis` (`id`),
  CONSTRAINT `catatanperawatan_ibfk_2` FOREIGN KEY (`id_perawatan`) REFERENCES `perawatan` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table clinic_management_schema.catatanperawatan: ~3 rows (approximately)
INSERT INTO `catatanperawatan` (`id`, `id_rekam`, `id_perawatan`) VALUES
	(4, 2, 2),
	(10, 2, 3);

-- Dumping structure for table clinic_management_schema.dokter
CREATE TABLE IF NOT EXISTS `dokter` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `spesialisasi` varchar(100) DEFAULT NULL,
  `telepon` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table clinic_management_schema.dokter: ~7 rows (approximately)
INSERT INTO `dokter` (`id`, `nama`, `spesialisasi`, `telepon`, `email`) VALUES
	(1, 'dr.Gigi yudha', 'gigii', '14', 'yudhabos@gmail.com'),
	(2, 'dr.LLambung dayat', 'lambung', '142', 'lambung@gmail.com'),
	(3, 'dr.Jantung maula', 'jantung', '56', 'jantung@gmail.com'),
	(5, 'dr.abil', 'penyaki dalam', '08975', 'abil@gmail.com'),
	(6, 'dr.yudhaboss', 'dr.kandungan bayi', '067', 'yudhabos@gmail.com'),
	(7, 'dr.izzan', 'penyakit hati', '1927', 'izzan@gmail.com'),
	(8, 'dr.yula', 'penyakitmata', '34254', 'yula@gmail.com');

-- Dumping structure for table clinic_management_schema.faktur
CREATE TABLE IF NOT EXISTS `faktur` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_janji` int DEFAULT NULL,
  `jumlah` decimal(10,2) DEFAULT NULL,
  `status` enum('belum dibayar','dibayar') DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `faktur_ibfk_1` (`id_janji`),
  CONSTRAINT `faktur_ibfk_1` FOREIGN KEY (`id_janji`) REFERENCES `resep` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table clinic_management_schema.faktur: ~2 rows (approximately)
INSERT INTO `faktur` (`id`, `id_janji`, `jumlah`, `status`) VALUES
	(8, 5, 4.00, 'belum dibayar'),
	(9, 5, 10.00, 'dibayar');

-- Dumping structure for table clinic_management_schema.file
CREATE TABLE IF NOT EXISTS `file` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_rekam` int DEFAULT NULL,
  `nama_file` varchar(255) DEFAULT NULL,
  `path_file` varchar(255) DEFAULT NULL,
  `tipe_file` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_rekam` (`id_rekam`),
  CONSTRAINT `file_ibfk_1` FOREIGN KEY (`id_rekam`) REFERENCES `rekammedis` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table clinic_management_schema.file: ~4 rows (approximately)
INSERT INTO `file` (`id`, `id_rekam`, `nama_file`, `path_file`, `tipe_file`) VALUES
	(8, 1, '220605110141_Yudha Pramana Putra.pdf', '../../file/220605110141_Yudha Pramana Putra.pdf', 'application/pdf'),
	(10, 2, 'HASIL RESEP PASIEN DI REKAM MEDIS.pdf', '../../file/HASIL RESEP PASIEN DI REKAM MEDIS.pdf', 'application/pdf'),
	(18, 3, 'RESEP DOKTER.pdf', '../../file/RESEP DOKTER.pdf', 'application/pdf');

-- Dumping structure for table clinic_management_schema.janjitemu
CREATE TABLE IF NOT EXISTS `janjitemu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_pasien` int DEFAULT NULL,
  `id_dokter` int DEFAULT NULL,
  `tanggal_janji` datetime DEFAULT NULL,
  `status` enum('dijadwalkan','selesai','batal') DEFAULT NULL,
  `formulir` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_pasien` (`id_pasien`),
  KEY `id_dokter` (`id_dokter`),
  CONSTRAINT `janjitemu_ibfk_1` FOREIGN KEY (`id_pasien`) REFERENCES `pasien` (`id`),
  CONSTRAINT `janjitemu_ibfk_2` FOREIGN KEY (`id_dokter`) REFERENCES `dokter` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table clinic_management_schema.janjitemu: ~6 rows (approximately)
INSERT INTO `janjitemu` (`id`, `id_pasien`, `id_dokter`, `tanggal_janji`, `status`, `formulir`) VALUES
	(3, 2, 1, '2024-05-26 15:00:00', 'dijadwalkan', 'makalah genetika populasi.docx'),
	(4, 4, 2, '2024-05-09 00:00:00', 'selesai', 'Dokumen tanpa judul (6).pdf'),
	(5, 2, 3, '2024-05-08 18:00:00', 'batal', 'makalah genetika populasi (4).docx'),
	(15, 3, 5, '2024-06-11 08:04:00', 'dijadwalkan', NULL),
	(16, 1, 6, '2024-06-11 08:05:00', 'dijadwalkan', NULL),
	(18, 5, 7, '2024-06-12 14:24:00', 'dijadwalkan', NULL),
	(20, 6, 8, '2024-06-13 06:56:00', 'dijadwalkan', 'Dokumen tanpa judul (6).pdf');

-- Dumping structure for table clinic_management_schema.pasien
CREATE TABLE IF NOT EXISTS `pasien` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `alamat` text,
  `telepon` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table clinic_management_schema.pasien: ~7 rows (approximately)
INSERT INTO `pasien` (`id`, `nama`, `alamat`, `telepon`, `email`) VALUES
	(1, 'junedd', 'situbondo', '272663', 'juned@gmail.com'),
	(2, 'agym', 'situbondo', '2333', 'agym@gmail.com'),
	(3, 'nurhid', 'bendengann', '233434', 'nurhdi@gmail.com'),
	(4, 'reval', 'malang', '454423', 'reval@gmail.com'),
	(5, 'ayah', 'pasuruan', '33344', 'jun@gmail.com'),
	(6, 'jua', 'bogor', '343', 'juo@gmail.com'),
	(7, 'juni', 'lampung', '456', 'juni@gmail.com'),
	(10, 'junda', 'sukorejo', '789', 'junda@gmail.com');

-- Dumping structure for table clinic_management_schema.pengguna
CREATE TABLE IF NOT EXISTS `pengguna` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','dokter','perawat','resepsionis') NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `pengguna_ibfk_1` FOREIGN KEY (`id`) REFERENCES `pasien` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table clinic_management_schema.pengguna: ~5 rows (approximately)
INSERT INTO `pengguna` (`id`, `username`, `password`, `role`) VALUES
	(1, 'yudha', '123', 'admin'),
	(2, 'dr.maula', '123', 'dokter'),
	(3, 'sada', '123', 'perawat'),
	(4, 'dayat', '123', 'resepsionis'),
	(5, 'ridiy', '123', 'admin'),
	(6, 'sudi', '123', 'perawat');

-- Dumping structure for table clinic_management_schema.perawatan
CREATE TABLE IF NOT EXISTS `perawatan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) DEFAULT NULL,
  `deskripsi` text,
  `biaya` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table clinic_management_schema.perawatan: ~5 rows (approximately)
INSERT INTO `perawatan` (`id`, `nama`, `deskripsi`, `biaya`) VALUES
	(2, 'sadaa', 'minta tambahan nasi', 760000.00),
	(3, 'reval', 'minta infus lagi', 21.00),
	(4, 'sada', 'minta nasi bakar', 10000.00),
	(5, 'juned', 'sudah dikasi obat bius', 2.00),
	(6, 'junedd', 'meberikan darah', 29000.00);

-- Dumping structure for table clinic_management_schema.rekammedis
CREATE TABLE IF NOT EXISTS `rekammedis` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_pasien` int DEFAULT NULL,
  `tanggal_rekam` datetime DEFAULT NULL,
  `deskripsi` text,
  PRIMARY KEY (`id`),
  KEY `id_pasien` (`id_pasien`),
  CONSTRAINT `rekammedis_ibfk_1` FOREIGN KEY (`id_pasien`) REFERENCES `pasien` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table clinic_management_schema.rekammedis: ~6 rows (approximately)
INSERT INTO `rekammedis` (`id`, `id_pasien`, `tanggal_rekam`, `deskripsi`) VALUES
	(1, 1, '2024-05-22 01:37:00', 'sakitpinggang'),
	(2, 2, '2024-06-04 02:37:00', 'mengalami cidera kaki'),
	(3, 5, '2024-06-12 14:29:44', 'sakit gigi'),
	(4, 6, '2024-06-12 14:30:10', 'pusing'),
	(5, 3, '2024-06-10 14:52:00', 'cidera leher'),
	(6, 4, '2024-06-11 08:01:00', 'mengalami sakit mataa');

-- Dumping structure for table clinic_management_schema.resep
CREATE TABLE IF NOT EXISTS `resep` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_janji` int DEFAULT NULL,
  `obat` varchar(255) DEFAULT NULL,
  `dosis` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_janji` (`id_janji`),
  CONSTRAINT `resep_ibfk_1` FOREIGN KEY (`id_janji`) REFERENCES `janjitemu` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table clinic_management_schema.resep: ~3 rows (approximately)
INSERT INTO `resep` (`id`, `id_janji`, `obat`, `dosis`) VALUES
	(4, 3, 'bodrex', '2xseharii'),
	(5, 4, 'sdfdsff', 'gsggfdgdf'),
	(7, 5, 'mixagrip', '3xsehari'),
	(8, 15, 'promaagg', '4xsehari');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
